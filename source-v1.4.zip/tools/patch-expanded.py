from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent

def replace(s,a,b,count=1):
    n=s.count(a)
    if n!=count: raise RuntimeError(f'Expected {count} matches, found {n}: {a[:110]}')
    return s.replace(a,b)

p=root/'build.cjs';s=p.read_text()
s=replace(s,"const courses=require('./src/openings.cjs');", "const courses=require('./src/openings.cjs');\nconst extras=JSON.parse(fs.readFileSync('data/expanded/repertoire-extra.json','utf8'));\nfor(const c of courses){for(const [i,l] of c.lines.entries()){l.id=c.id+'-'+i;l.group='base';}c.lines.push(...(extras[c.id]||[]));}\nconst REPERTOIRE_INFO={version:'1.4.0',legacy:61,added:Object.values(extras).reduce((n,l)=>n+l.length,0),total:courses.reduce((n,c)=>n+c.lines.length,0)};")
s=replace(s,"l.id=c.id+'-'+i;l.history=", "l.id=l.id||c.id+'-'+i;l.history=")
s=replace(s,"'\\nconst COURSES = '+JSON.stringify(courses)","'\\nconst REPERTOIRE_INFO = '+JSON.stringify(REPERTOIRE_INFO)+';\\nconst COURSES = '+JSON.stringify(courses)")
s=replace(s,"escScript(fs.readFileSync('src/academy.js','utf8'))+'\\nbegin", "escScript(fs.readFileSync('src/academy.js','utf8'))+'\\n'+escScript(fs.readFileSync('src/repertoire.js','utf8'))+'\\nbegin")
p.write_text(s)

p=root/'src/app.js';s=p.read_text()
s=replace(s,"variation:'mix',depth:0,opponent:'auto'", "variation:'mix',lineSet:'all',depth:0,opponent:'auto'")
s=replace(s,"if(!c.lines.some(l=>l.id===variation))variation='mix';const pool=variation==='mix'?c.lines:[c.lines.find(l=>l.id===variation)];S={course:c,side,mode,variation,", "const available=eligibleLines(c,side);if(!available.some(l=>l.id===variation))variation='mix';let lineSet=opts.lineSet??db.prefs.lineSet??'all';if(!Object.hasOwn(LINE_SETS,lineSet))lineSet='all';const pool=variation==='mix'?poolForCourse(c,side,lineSet):[available.find(l=>l.id===variation)];S={course:c,side,mode,variation,lineSet,")
s=replace(s,"depth:[0,5,8].includes(Number(db.prefs.depth))", "depth:[0,5,8,12,16].includes(Number(db.prefs.depth))")
s=replace(s,"S.pool=c.lines.filter(l=>prefix(l,m.historySans));", "S.pool=eligibleLines(c,m.side).filter(l=>prefix(l,m.historySans));")
s=replace(s,"S.pool=c.lines;S.game.reset();", "S.pool=available;S.game.reset();")
s=replace(s,"variation:S.variation,depth:S.depth,opponent:S.manual?'manual':'auto'", "variation:S.variation,lineSet:S.lineSet,depth:S.depth,opponent:S.manual?'manual':'auto'")
s=replace(s,"const alt=S.course.lines.filter(l=>prefix(l,next));", "const alt=eligibleLines(S.course,S.side).filter(l=>prefix(l,next));")
s=replace(s,"S.variation='mix';S.pool=S.course.lines;S.active=", "S.variation='mix';S.lineSet='all';S.pool=eligibleLines(S.course,S.side);S.active=")
s=replace(s,"db.prefs.variation='mix';S.pending=null;attempt", "db.prefs.variation='mix';db.prefs.lineSet='all';populateVariation();S.pending=null;attempt")
lines=s.splitlines()
for i,line in enumerate(lines):
    if line.startswith('function populateVariation(){'):lines[i]='function populateVariation(){populateExpandedVariation();}'
    if line.startswith('function renderBranches(){'):lines[i]='function renderBranches(){renderExpandedBranches();}'
s='\n'.join(lines)+'\n'
s=replace(s,"renderGuide();renderMoves();renderBranches();renderCompletion();renderManualControls();}","renderGuide();renderMoves();renderBranches();renderCompletion();renderManualControls();syncRepertoireControls();}")
s=replace(s,"$('branchCount').textContent=S.course.lines.length", "$('branchCount').textContent=eligibleLines(S.course,S.side).length")
s=replace(s,"'+c.lines.length+' ветки", "'+eligibleLines(c,S.side).length+' веток")
s=s.replace("S.side==='w'?S.course.whitePlan:S.course.blackPlan", "S.side==='w'?(S.active.whitePlan||S.course.whitePlan):(S.active.blackPlan||S.course.blackPlan)")
s=s.replace("S.side==='w'?S.course.blackPlan:S.course.whitePlan", "S.side==='w'?(S.active.blackPlan||S.course.blackPlan):(S.active.whitePlan||S.course.whitePlan)")
s=s.replace("$('courseWarning').textContent=S.course.warning", "$('courseWarning').textContent=S.active.warning||S.course.warning")
s=s.replace('Версия приложения 1.3.','Версия приложения 1.4.')
p.write_text(s)

p=root/'src/manual.js';s=p.read_text()
s=replace(s,"[S.active,...S.course.lines.filter(l=>l.id!==S.active.id)]", "[S.active,...eligibleLines(S.course,S.side).filter(l=>l.id!==S.active.id)]")
s=s.replace("S.side==='w'?S.course.whitePlan:S.course.blackPlan", "S.side==='w'?(S.active.whitePlan||S.course.whitePlan):(S.active.blackPlan||S.course.blackPlan)")
s=s.replace("S.side==='w'?S.course.blackPlan:S.course.whitePlan", "S.side==='w'?(S.active.blackPlan||S.course.blackPlan):(S.active.whitePlan||S.course.whitePlan)")
s=s.replace("$('courseWarning').textContent=S.course.warning", "$('courseWarning').textContent=S.active.warning||S.course.warning")
p.write_text(s)

p=root/'src/shell.html';s=p.read_text()
s=replace(s,'<option value="8">8 ходов</option>','<option value="8">8 ходов</option><option value="12">12 ходов</option><option value="16">16 ходов</option>')
needle='<div class="coach-tabs" id="coachTabs">'
controls='<div class="repertoire-controls"><label class="field-label" for="lineSet">НАБОР ДЛЯ СМЕШАННОЙ ТРЕНИРОВКИ</label><select id="lineSet"><option value="all">Все варианты</option><option value="new">Только новые</option><option value="early">Ранние отклонения</option><option value="deeper">Продолжения знакомых линий</option><option value="base">Старая база</option></select><p id="poolMeta" class="small muted"></p><button id="practiceNew" data-action="practice-new" class="secondary full">Учить новые ответы →</button></div>'
s=replace(s,needle,controls+needle)
s=replace(s,'<div id="branchList" class="branch-list"></div>','<div id="branchTools" class="branch-tools"><input id="branchSearch" type="search" placeholder="Поиск ветки или ответа…" aria-label="Поиск по веткам"><select id="branchScope" aria-label="Набор веток"><option value="all">Все ветки</option><option value="new">Только новые</option><option value="early">Ранние отклонения</option><option value="deeper">Продолжения</option><option value="base">Старая база</option></select></div><div id="branchList" class="branch-list"></div>')
p.write_text(s)

p=root/'src/style.css';p.write_text(p.read_text()+'''\n/* Repertoire expansion, v1.4 */
.repertoire-controls{border:1px solid var(--line);border-radius:12px;padding:14px;background:var(--panel);margin:-5px 0 20px}.repertoire-controls p{font-size:10px;line-height:1.6;margin:9px 0 11px}.repertoire-controls .secondary{font-size:11px;padding:9px}.branch-tools{display:grid;grid-template-columns:1fr;gap:8px;margin-bottom:12px}.branch-tools input{width:100%;min-width:0;background:#172025;border:1px solid #39494c;padding:9px;border-radius:8px;color:var(--ink);font-size:12px}.branch-list{max-height:70vh;overflow:auto;overscroll-behavior:contain;scrollbar-width:thin}.branch-badges{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px}.branch-badges span{font-size:8px;border:1px solid #40503e;background:#27362b;color:#c2dfaa;border-radius:4px;padding:2px 5px}.branch-badges .branch-complete{background:#32431e}.branch-item .source-caption{font-size:9px;color:#899b9b;line-height:1.6;border-left:2px solid #4e6252;padding-left:7px;margin:10px 0}.branch-item small{float:none;display:block;margin-top:7px}.repertoire-release{border-top:1px solid var(--line);margin-top:24px;padding-top:7px}
@media(max-width:690px){.repertoire-controls{margin-top:0}.repertoire-controls select,.branch-tools input,.branch-tools select{font-size:16px}.branch-tools{grid-template-columns:1fr}.repertoire-controls p{font-size:11px}.branch-list{max-height:60vh}.branch-item h3{font-size:14px}.branch-item p{font-size:12px}.branch-item button{min-height:40px;font-size:12px}.branch-badges span{font-size:10px}.branch-item .source-caption{font-size:10px}}\n''')
p=root/'package.json';obj=json.loads(p.read_text());obj['version']='1.4.0';obj['scripts']['test:expanded']='node tests/expanded.cjs';p.write_text(json.dumps(obj,indent=2)+'\n')
print('EXPANSION_PATCHED')
